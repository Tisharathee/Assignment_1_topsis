# Topsis-Tanishka-102303245

This package implements the TOPSIS method.

## Installation
```bash
pip install Topsis-Tanishka-102303245
